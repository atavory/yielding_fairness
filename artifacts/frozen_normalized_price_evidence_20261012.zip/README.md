# Corrected normalized-price evidence, 2026-10-12

This is a post-review sensitivity, using the existing frozen candidate splits.
Both families use validation-normalized prices. The common axis retains every
original physical policy and is extended using validation only; all choices
and LP weights were frozen before this run read test rows. Original results
remain in the historical 20261011 archive.

At the .95 capture floor, the seven-source mean of source-median closure lifts
is +.2185 (two-sided p=.3071); the ten-source mean is +.0863 (p=.6007).
Neither establishes statistically significant average group-aware superiority.
All negative cells and source-mean sensitivities are retained.

Install numpy and scipy. From this archive root, independently verify all 2,880
LP cells and generate the three manuscript tables without raw data:

python scripts/bandha_verify_normalized_prices.py --freeze results/bandha_normalized_prices/validation_freeze.json.gz --output independent_lp_check.json
python scripts/bandha_render_normalized_tables.py --results results/bandha_normalized_prices --output regenerated_tables

The validation freeze includes full candidate-bank metrics, thresholds,
thinning probabilities, coverage traces, selections, LP weights, and exact
compressed candidate-input checksums. heldout_comparison.csv and selected
component masses record expected test outcomes under frozen thinning.
The independent candidate replay report checks 192 selected policies using
the original scalar scorer, budget threshold, and metric implementation.

To rerun candidate evaluation, supply the exact candidate CSV.gz files listed
in validation_freeze.json.gz under their recorded paths in a local base dir:
python scripts/bandha_normalized_group_prices.py --base-dir BASE --stage all
Raw input data remain external; the public repository's candidate runners and
input documentation describe their construction. Generating the manuscript
tables and independent LP verification above need only this archive.
