The independent devvm run used a wider common global base grid ending at 512000,
then preserved both original physical families with G union r_all*G. Its
128000, 256000, and 512000 passes had unchanged selections. At .95, ten-source
mean source-median lift is +.0202 (p=.8990); mean source-mean lift is -.6209
(p=.1207). These are separate finite banks, with the same frozen outcome
proxies and units. Both analyses fail to establish significant average
superiority. The main LP table uses the independently verified per-cell bank.
The source vectors and raw comparisons are included; the global-grid generator
and full command/axis provenance are included under global_grid_scripts and
results. Historical physical policy formulas remain the default.
