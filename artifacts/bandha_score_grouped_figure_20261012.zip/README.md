Figure 3: fixed raw W-BCE minus BCE, two metrics on ten datasets.

Run: python3 viz/bandha_make_score_grouped_figure.py --base-dir .

Inputs are frozen paired summary CSVs; no models are retrained.
The output retains all twenty means and paired 95% confidence intervals.
The manuscript plots yield-Gini and capture deltas as paired bars in one column.
